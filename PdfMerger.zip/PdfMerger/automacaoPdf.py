import PyPDF2
import os

merge = PyPDF2.PdfMerger()

lista_arquivo = os.listdir("arquivos")
lista_arquivo.sort()

for arquivo in lista_arquivo:
    if ".pdf" in arquivo:
        merge.append(f"arquivos/{arquivo}")

merge.write("PDF_Final.pdf")
